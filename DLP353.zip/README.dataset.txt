# Lime Fruit > 2024-09-16 6:58am
https://universe.roboflow.com/shreyan-kundu-6fdmj/lime-fruit

Provided by a Roboflow user
License: CC BY 4.0

